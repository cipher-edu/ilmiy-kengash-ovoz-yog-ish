# ilmiy-kengash-ovoz-yog-ish
Navoiy davlat pedagogika institutida ilmiy kengash ishlarini raqamlilashtirish
